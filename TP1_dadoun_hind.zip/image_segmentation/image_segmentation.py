# from skimage import io
# import numpy as np
# import matplotlib.pyplot as plt
# import os
# import sys
# path=os.path.dirname(os.getcwd())
# sys.path.append(path)
# from helper import *
# from spectral_clustering.funcs import *
# import scipy.spatial.distance as sd
# #%matplotlib inline
#
# def image_segmentation(input_img):
#     #      a skeleton function to perform image segmentation, needs to be completed
#     #  Input
#     #  input_img:
#     #      (string) name of the image file, without extension (e.g. 'four_elements.bmp')
#     filename = path+'/'+input_img
#
#     X = io.imread(filename)
#     X=(X - np.min(X)) / (np.max(X) - np.min(X))
#
#     im_side = np.size(X,1)
#     Xr=X.reshape(im_side**2,3)
#     #################################################################
#     # Y_rec should contain an index from 1 to c where c is the      #
#     # number of segments you want to split the image into           #
#     #################################################################
#
#     var=1
#
#     W = build_similarity_graph(Xr, eps=0.001)
#     L = build_laplacian(W, laplacian_normalization="rw")
#     Y_rec = spectral_clustering(L, [1, 2], num_classes)
#
#     #################################################################
#     #################################################################
#
#     plt.figure()
#
#     plt.subplot(1,2,1)
#     plt.imshow(X)
#
#
#     plt.subplot(1,2,2)
#     Y_rec=Y_rec.reshape(im_side,im_side)
#     plt.imshow(Y_rec)
#
#     plt.show()
#
#
#
#
# # dists = sd.cdist(Xr, Xr, 'euclidean')**2
# # exponential_euclidean = np.exp(-dists)
# # var = np.var(exponential_euclidean)
# # num_classes = 5
#

from skimage import io
import numpy as np
import scipy.spatial.distance as sd
import matplotlib
import matplotlib.pyplot as plt
import os
import sys
path=os.path.dirname(os.getcwd())
sys.path.append(path)
from helper import *
from graph_construction.func import *
from spectral_clustering.funcs import *
def image_segmentation(filename):
    X = io.imread(filename)
    X=(X - np.min(X)) / (np.max(X) - np.min(X))

    im_side = np.size(X,1)
    Xr=X.reshape(im_side**2,3)

    W = build_similarity_graph(Xr, eps=0.001,var=1)
    L =  build_laplacian(W, laplacian_normalization="rw")
    Y_rec= spectral_clustering(L, [1,2,3], 5)

    plt.figure()

    plt.subplot(1,2,1)
    plt.imshow(X)


    plt.subplot(1,2,2)
    Y_rec=Y_rec.reshape(im_side,im_side)
    plt.imshow(Y_rec)