import numpy as np
import matplotlib.pyplot as pyplot
import scipy.spatial.distance as sd
import sys
import os


sys.path.append(os.path.dirname(os.getcwd()))
from helper import *
from graph_construction.generate_data import *

def build_similarity_graph(X, var=1, eps=0, k=0):



    assert eps + k != 0, "Choose either epsilon graph or k-nn graph"

    n=X.shape[0]
    dists=np.zeros((n,n))
    for j in range(n):
        dists[j,:] = [np.linalg.norm(X[i,]-X[j,]) for i in range(n)]
    similarities =np.exp(-(dists**2)/var)



    if eps:
        similarities = (similarities >= eps)* similarities

        return similarities




    if k:

        for i in range(similarities.shape[0]):
            indices=np.argsort(-similarities[:,i])[(k+1):]
            similarities[indices,i]=0
            similarities[i,i]=0
            #similarities[i,indices]=0
        similarities = np.maximum(similarities, similarities.T)
        return similarities

#################################################################
#################################################################



def plot_similarity_graph(X, Y,k,eps):

    var=1
    similarity=build_similarity_graph(X, var, k=k,eps=eps)
    W=(similarity>0).astype(int)
    plot_graph_matrix(X,Y,W)
    


def how_to_choose_epsilon( gen_pam = 1):

    num_samples = 100

    [X, Y] = worst_case_blob(num_samples,gen_pam)

    var = 1
    n = X.shape[0]
    dists = np.zeros((n, n))
    for j in range(n):
        dists[j, :] = [np.linalg.norm(X[i,] - X[j,]) for i in range(n)]
    similarities = np.exp(-(dists ** 2) / var)
    
    max_tree =max_span_tree(similarities)

    eps =np.min(similarities[max_tree>0])
    print('eps=',eps)
    similarity=build_similarity_graph(X,var,eps,k=0)
    W = (similarity > 0).astype(int)
    plot_graph_matrix(X, Y, W)

#################################################################
##################################################################