import numpy as np
import matplotlib.pyplot as pyplot
import scipy.spatial.distance as sd
import sklearn.cluster as skc
import sklearn.metrics as skm
import scipy
import scipy
import sys
import os

path=os.path.dirname(os.getcwd())
sys.path.append(path)
from helper import *
from graph_construction.func import *
from sklearn.cluster import KMeans

def build_laplacian(W, laplacian_normalization=""):
    D=np.zeros(W.shape)
    L=np.zeros(W.shape)
    D=np.diag(np.sum(W,axis=0))
    if laplacian_normalization=='unn':
        L=D-W
        return(L)
    if laplacian_normalization=='sym':
        d = np.diag(np.sum(W,axis=0) ** (-0.5))
        L=d.dot(D-W).dot(d)
        return(L)
    if laplacian_normalization == 'rw':
        d = np.diag(np.sum(W,axis=0)** (-1))
        L =d.dot(D - W)
        return(L)
    else :
        print('error,please use a valid name : sym,unn,rw')


def spectral_clustering(L, chosen_eig_indices, num_classes=2):


    [E, U] = np.linalg.eig(L)
    E = E[E.argsort()].real
    U = U[:, E.argsort()].real

    eig_vect=U[:,chosen_eig_indices].real
    kmeans=KMeans(n_clusters=num_classes,random_state=1231)
    Y = kmeans.fit(eig_vect).labels_

    return Y


def two_blobs_clustering(eps,var,k):

    in_data =scipy.io.loadmat(path+'/code_material_python/data/data_2blobs')
    X = in_data['X']
    Y = in_data['Y']

    num_classes = len(np.unique(Y))

    laplacian_normalization = 'unn'; #either 'unn'normalized, 'sym'metric normalization or 'rw' random-walk normalization


    # build laplacian
    W=build_similarity_graph(X, var=var, eps=eps, k=k)
    plot_graph_matrix(X,Y,W)
    L =build_laplacian(W, laplacian_normalization=laplacian_normalization)
    #plt.imshow(L)
    [E, U] = np.linalg.eig(L)
    E = E[E.argsort()].real
    U = U[:, E.argsort()].real
    plt.plot(E, '+')
    chosen_eig_indices = np.argsort(E.real)[1:num_classes]
    Y_rec = spectral_clustering(L, [0,1], num_classes=num_classes)
    plot_clustering_result(X, Y, L, Y_rec,skc.KMeans(num_classes).fit_predict(X))


    
    
def choose_eig_function(eigenvalues):
    eigengaps = np.diff(eigenvalues)
    max_index=np.argsort(-eigengaps)[0]
    eig_ind=list(range(1, max_index + 2))
    return eig_ind



def spectral_clustering_adaptive(L, num_classes=2):

    [E, U] = np.linalg.eig(L)
    E = E[E.argsort()].real
    U = U[:, E.argsort()].real

    chosen_eig_indices=choose_eig_function(E)
    eig_vect = U[:, chosen_eig_indices].real
    kmeans = KMeans(n_clusters=num_classes,random_state=1231)
    Y = kmeans.fit(eig_vect).labels_


    return Y



def find_the_bend(sigma,eps,k):
    #      a skeleton function for question 2.3 and following, needs to be completed
    #

    # the number of samples to generate
    num_samples = 600

    [X, Y] = blobs(num_samples,4,sigma)

    # automatically infer number of clusters from samples
    num_classes = len(np.unique(Y));


    var = 1 # exponential_euclidean's sigma^2

    laplacian_normalization = 'rw'; #either 'unn'normalized, 'sym'metric normalization or 'rw' random-walk normalization


    # build the laplacian
    W = build_similarity_graph(X, var=var, eps=eps, k=k)
    plot_graph_matrix(X, Y, W)
    L = build_laplacian(W, laplacian_normalization=laplacian_normalization)


    E = np.zeros(L.shape[0])
    U = np.zeros(L.shape[0])
    [E, U] = np.linalg.eig(L)
    E = E[E.argsort()].real
    U = U[:, E.argsort()].real
    eigenvalues = E[:15]
    chosen_eig_indices = np.argsort(E.real)[1:num_classes]

    Y_rec =spectral_clustering_adaptive(L, num_classes=num_classes)
    Y_rec1 = spectral_clustering(L, chosen_eig_indices, num_classes=num_classes)


    #################################################################
    #################################################################

    print('adaptative')
    plot_the_bend(X, Y, L, Y_rec, eigenvalues)
    print('non adaptative')
    plot_the_bend(X, Y, L, Y_rec1, eigenvalues)





def two_moons_clustering(k,eps):
    #       a skeleton function for questions 2.7

    # load the data

    in_data =scipy.io.loadmat(path+'/code_material_python/data/data_2moons')
    X = in_data['X']
    Y = in_data['Y']

    # automatically infer number of labels from samples
    num_classes = len(np.unique(Y))

    #################################################################
    # choose the experiment parameter                               #
    #################################################################

    var = 1; # exponential_euclidean's sigma^2

    laplacian_normalization ='rw' ; #either 'unn'normalized, 'sym'metric normalization or 'rw' random-walk normalization
    chosen_eig_indices =np.arange(1,2)  # indices of the ordered eigenvalues to pick

    #################################################################
    #################################################################

    # build laplacian
    W = build_similarity_graph(X, var=var, eps=eps, k=k)
    plot_graph_matrix(X, Y, W)
    L = build_laplacian(W, laplacian_normalization=laplacian_normalization)

    Y_rec = spectral_clustering(L, chosen_eig_indices, num_classes=num_classes)
    print('non adaptative')
    plot_clustering_result(X, Y, L, Y_rec,skc.KMeans(num_classes).fit_predict(X))
    # print('adaptative')
    # Y_rec1 = spectral_clustering_adaptive(L, num_classes=num_classes)
    # plot_clustering_result(X, Y, L, Y_rec1,skc.KMeans(num_classes).fit_predict(X))

def plot_evalues(L):
    E = np.zeros(L.shape[0])
    U = np.zeros(L.shape[0])
    [E, U] = np.linalg.eig(L)
    E = E[E.argsort()].real
    U = U[:, E.argsort()].real
    plt.plot(E, '+')

def point_and_circle_clustering(eps,k,var):
    #  [] = point_and_circle_clustering()
    #       a skeleton function for questions 2.8

    # load the data

    in_data =scipy.io.loadmat(path+'/code_material_python/data/data_pointandcircle')
    X = in_data['X']
    Y = in_data['Y']

    # automatically infer number of labels from samples
    num_classes = len(np.unique(Y))

    #################################################################
    # choose the experiment parameter                               #
    #################################################################

     # exponential_euclidean's sigma^2


    laplacian_normalization = 'rw'; #either 'unn'normalized, 'sym'metric normalization or 'rw' random-walk normalization
    chosen_eig_indices = np.arange(1,2) # indices of the ordered eigenvalues to pick

    #################################################################
    #################################################################

    # build laplacian
    W=build_similarity_graph(X, var=var, eps=eps, k=k)

    L_unn =build_laplacian(W, laplacian_normalization='unn')


    L_norm =build_laplacian(W, laplacian_normalization=laplacian_normalization)


    Y_unn =spectral_clustering(L_unn,chosen_eig_indices, num_classes=num_classes)
    Y_norm =spectral_clustering(L_norm,chosen_eig_indices, num_classes=num_classes)


    plot_clustering_result(X, Y, W, Y_unn, Y_norm, 1);


def parameter_sensitivity():
    # parameter_sensitivity
    #       a skeleton function to test spectral clustering
    #       sensitivity to parameter choice

    # the number of samples to generate
    num_samples = 500;


    #################################################################
    # choose the experiment parameter                               #
    #################################################################

    var =1 ; # exponential_euclidean's sigma^2

    laplacian_normalization ='unn' ; #either 'unn'normalized, 'sym'metric normalization or 'rw' random-walk normalization
    chosen_eig_indices = [1,2,3] # indices of the ordered eigenvalues to pick

    parameter_candidate = range(1,20)  # the number of neighbours for the graph or the epsilon threshold
    parameter_performance=[]
    #################################################################
    #################################################################


    for k in parameter_candidate:

        #graph_param.graph_thresh = parameter_candidate(i);

        [X, Y] = two_moons(num_samples,1,0.02)

        # automatically infer number of labels from samples
        num_classes = len(np.unique(Y))

        W=build_similarity_graph(X, k=k)
        L =  build_laplacian(W, laplacian_normalization='unn')

        Y_rec = spectral_clustering(L, chosen_eig_indices, num_classes)

        parameter_performance+= [skm.adjusted_rand_score(Y,Y_rec)]

    plt.figure()
    plt.plot(parameter_candidate, parameter_performance)
    plt.title('parameter sensitivity')
    #plt.show()
