import matplotlib.pyplot as pyplot
import scipy.misc as sm
import numpy as np
import cv2
import os
import sys
import copy

path=os.path.dirname(os.getcwd())
sys.path.append(path)
from DM2.code_material_python.harmonic_function_solution.func import*
def offline_face_recognition(laplacian_normalization='',soft=True):
#     a skeleton function to test offline face recognition, needs to be completed

    # Parameters
    cc = cv2.CascadeClassifier('/Users/hinddadoun/Desktop/MVA/ML_in_graphs/DM2/code_material_python/data/haarcascade_frontalface_default.xml')


    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))

    frame_size = 96
    gamma = .95

    # Loading images
    images = np.zeros((100, frame_size ** 2))
    labels = np.zeros(100)
    var=10000000

    for i in np.arange(10):
      for j in np.arange(10):
        im = sm.imread(path+"/ML_in_graphs/DM2/code_material_python/data/10faces/%d/%02d.jpg" % (i, j + 1))
        box = cc.detectMultiScale(im)
        top_face = {"area": 0}
    
    
    
        for cfx, cfy, clx, cly in box:
            face_area = clx * cly
            if face_area > top_face["area"]:
                top_face["area"] = face_area
                top_face["box"] = [cfx, cfy, clx, cly]

        fx, fy, lx, ly = top_face["box"]
        gray_im = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
        gray_face = gray_im[fy:fy + ly, fx:fx + lx]

        #gray_face = cv2.GaussianBlur(gray_face, (5, 5), 0)
        #gray_face = cv2.boxFilter(gray_face, -1, (15, 15))
        #gray_face = clahe.apply(gray_face)

        #######################################################################
        # Apply preprocessing to balance the image (color/lightning), such    #
        # as filtering (cv.boxFilter, cv.GaussianBlur, cv.bilinearFilter) and #
        # equalization (cv.equalizeHist).                                     #
        #######################################################################

        gray_face = cv2.resize(gray_face, (frame_size, frame_size), interpolation=cv2.INTER_CUBIC)
        gf = cv2.GaussianBlur(gray_face, (5, 5), 0)
        gf = cv2.equalizeHist(gf)

        gf = clahe.apply(gf)

        #######################################################################
        #######################################################################

        #resize the face and reshape it to a row vector, record labels
        images[j * 10 + i] = gf.reshape((-1))
        labels[j * 10 + i] = i + 1
        
        
        
    # if you want to plot the dataset, set the following variable to 1
    ##################################################################
    plot_the_dataset = 1
    ##################################################################
    ##################################################################
    if plot_the_dataset:

     pyplot.figure(1)
     for i in range(100):
        pyplot.subplot(10,10,i+1)
        pyplot.axis('off')
        pyplot.imshow(images[i].reshape(frame_size,frame_size))
        r='{:d}'.format(i+1)
        if i<10:
         pyplot.title('Person '+r)
     pyplot.show()  
 
 
        

    #################################################################
    # select 4 random labels per person and reveal them             #
    # Y_masked: (n x 1) masked label vector, where entries Y_i      #
    #       takes a value in [1..num_classes] if the node is        #
    #       labeled, or 0 if the node is unlabeled (masked)         #
    #################################################################
    copy_labels=copy.deepcopy(labels)

    for i in range(10):
        r_sample=random.sample(range(10), 6)
        for j in r_sample:
            copy_labels[i * 10 + j] =0



    Y_masked=copy_labels
    if soft==True:
        rlabels = soft_hfs(images, Y_masked, 1,0.000000001,gamma, laplacian_normalization,var=var, eps=0.01, k=0)
    else:
        rlabels = hard_hfs(images, Y_masked, gamma, laplacian_normalization, var=var, eps=0.01, k=0)


    # # Plots #
    pyplot.subplot(131)
    pyplot.imshow(labels.reshape((10, 10)))
    pyplot.title("Ground truth")



    pyplot.subplot(133)
    pyplot.imshow(rlabels.reshape((10, 10)))
    pyplot.title("Acc: {}".format(np.equal(rlabels, labels).mean()))

    pyplot.show()
    
    
    
    
    
    
    
    
def offline_face_recognition_augmented(laplacian_normalization='',soft=True):
#     a skeleton function to test offline face recognition, needs to be completed

    # Parameters

    cc = cv2.CascadeClassifier('/Users/hinddadoun/Desktop/MVA/ML_in_graphs/DM2/code_material_python/data/haarcascade_frontalface_default.xml')


    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))

    frame_size = 96
    gamma = .95
    nbimgs = 50
    # Loading images
    images = np.zeros((10 * nbimgs, frame_size ** 2))
    labels = np.zeros(10 * nbimgs)


    var=10000000

    for i in np.arange(10):
      imgdir = path+"/ML_in_graphs/DM2/code_material_python/data/extended_dataset/%d" % i
      imgfns = os.listdir(imgdir)
      for j, imgfn in enumerate(np.random.choice(imgfns, size=nbimgs)):
        im = sm.imread("{}/{}".format(imgdir, imgfn))
        box = cc.detectMultiScale(im)
        top_face = {"area": 0, "box": (0, 0, *im.shape[:2])}

        for cfx, cfy, clx, cly in box:
            face_area = clx * cly
            if face_area > top_face["area"]:
                top_face["area"] = face_area
                top_face["box"] = [cfx, cfy, clx, cly]


        fx, fy, lx, ly = top_face["box"]
        gray_im = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
        gray_face = gray_im[fy:fy + ly, fx:fx + lx]
        
        #######################################################################
        # Apply preprocessing to balance the image (color/lightning), such    #
        # as filtering (cv.boxFilter, cv.GaussianBlur, cv.bilinearFilter) and #
        # equalization (cv.equalizeHist).                                     #
        #######################################################################
        gray_face = cv2.resize(gray_face, (frame_size, frame_size), interpolation=cv2.INTER_CUBIC)


        gf = cv2.GaussianBlur(gray_face, (5, 5), 0)
        gf = cv2.equalizeHist(gf)
        gf = clahe.apply(gf)
        #######################################################################
        #######################################################################

        #resize the face and reshape it to a row vector, record labels
        images[i*nbimgs +j ] = gf.reshape((-1))
        labels[i*nbimgs +j] = i + 1
        
        
        
    # if you want to plot the dataset, set the following variable to 1

    plot_the_dataset = 1

    if plot_the_dataset:

     pyplot.figure(1)
     for i in range(10 * nbimgs):
        pyplot.subplot(nbimgs,10,i+1)
        pyplot.axis('off')
        pyplot.imshow(images[i].reshape(frame_size,frame_size))
        r='{:d}'.format(i+1)
        if i<10:
         pyplot.title('Person '+r)
     pyplot.show()  
 
 
        

    #################################################################
    # select 4 random labels per person and reveal them             #
    # Y_masked: (n x 1) masked label vector, where entries Y_i      #
    #       takes a value in [1..num_classes] if the node is        #
    #       labeled, or 0 if the node is unlabeled (masked)         #
    #################################################################


    copy_labels = copy.deepcopy(labels)

    for i in range(10):
        r_sample = random.sample(range(nbimgs), 46)
        for j in r_sample:
            copy_labels[i * nbimgs + j] = 0

    Y_masked = copy_labels


    if soft == True:
        rlabels = soft_hfs(images, Y_masked, 1, 0.000000001, gamma, laplacian_normalization, var=var, eps=0.01, k=0)
    else:
        rlabels = hard_hfs(images, Y_masked, gamma, laplacian_normalization, var=var, eps=0.01, k=0)




    #######################################################################
    #######################################################################
    #################################################################
    # choose the experiment parameter and                           #
    # compute hfs solution using either soft_hfs or hard_hfs        #
    #################################################################




    # # Plots #
    pyplot.subplot(131)
    pyplot.imshow(labels.reshape((-1, 10)))
    pyplot.title("Ground truth")

    pyplot.subplot(132)
    pyplot.imshow(rlabels.reshape((-1, 10)))
    pyplot.title("Acc: {}".format(np.equal(rlabels, labels).mean()))

    pyplot.show()
