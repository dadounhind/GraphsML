import numpy as np
import matplotlib.pyplot as pyplot
import scipy.spatial.distance as sd
import sys
import os

path=os.path.dirname(os.getcwd())
sys.path.append(path)
#from graph_construction.func import *


import matplotlib.pyplot as plt
import scipy
import numpy as np
import networkx as nx
import random
import scipy.io
import scipy.spatial.distance as sd



def is_connected(adj, n):
    # Uses the fact that multiplying the adj matrix to itself k times give the
    # number of ways to get from i to j in k steps. If the end of the
    # multiplication in the sum of all matrices there are 0 entries then the
    # graph is disconnected. Computationally intensive, but can be sped up by
    # the fact that in practice the diameter is very short compared to n, so it
    # will terminate in order of log(n)? steps.
    adjn = np.zeros((n, n))
    adji = adj.copy()
    for i in range(n):
        adjn += adji
        adji = adji.dot(adj)
    return len(np.where(adjn == 0)[0]) == 0


def max_span_tree(adj):
    n = adj.shape[0]
    if not (is_connected(adj, n)):
        print('This graph is not connected. No spanning tree exists')
    else:
        tr = np.zeros((n, n))
        adj[adj == 0] = -np.inf
        conn_nodes = [0]
        rem_nodes = [i + 1 for i in range(n - 1)]
        while len(rem_nodes) > 0:
            L = np.zeros(n)
            L[conn_nodes] = 1
            L = L.reshape(n, 1)
            C = np.zeros(n)
            C[rem_nodes] = 1
            C = C.reshape(1, n)
            B = L.dot(C)
            A = B * adj
            i = np.where(A == np.max(A))[0][0]
            j = np.where(A == np.max(A))[1][0]
            tr[i, j] = 1
            tr[j, i] = 1
            conn_nodes += [j]
            rem_nodes.remove(j)
    return tr.astype(int)

def how_to_choose_epsilon(X, var = 1.0):
    dists = sd.cdist(X, X, 'euclidean')
    similarities = np.exp(-dists/var/2)
    max_tree = max_span_tree(similarities)
    eps = np.min(similarities[max_tree > 0])
    return eps

def build_similarity_graph(X, var=1, eps=0, k=0):
    #      Computes the similarity matrix for a given dataset of samples.
    #
    #  Input
    #  X:
    #      (n x m) matrix of m-dimensional samples
    #  k and eps:
    #      controls the main parameter of the graph, the number
    #      of neighbours k for k-nn, and the threshold eps for epsilon graphs
    #  var:
    #      the sigma value for the exponential function, already squared
    #
    #
    #  Output
    #  W:
    #      (n x n) dimensional matrix representing the adjacency matrix of the graph
    #  similarities:
    #      (n x n) dimensional matrix containing
    #      all the similarities between all points (optional output)

    assert eps + k != 0, "Choose either epsilon graph or k-nn graph"

    #################################################################
    #  build full graph
    #  similarities: (n x n) matrix with similarities between
    #  all possible couples of points.
    #  The similarity function is d(x,y)=exp(-||x-y||^2/var)
    #################################################################
    # euclidean distance squared between points
    dists = sd.squareform(sd.pdist(X, "sqeuclidean"))

    similarities = np.exp(-dists / var)


    #################################################################
    #################################################################
    if eps:
        #################################################################
        #  compute an epsilon graph from the similarities               #
        #  for each node x_i, an epsilon graph has weights              #
        #  w_ij = d(x_i,x_j) when w_ij > eps, and 0 otherwise           #
        #################################################################
        similarities[similarities < eps] = 0

        return similarities

    #################################################################
    #################################################################

    if k:
        #################################################################
        #  compute a k-nn graph from the similarities                   #
        #  for each node x_i, a k-nn graph has weights                  #
        #  w_ij = d(x_i,x_j) for the k closest nodes to x_i, and 0      #
        #  for all the k-n remaining nodes                              #
        #  Remember to remove self similarity and                       #
        #  make the graph undirected                                    #
        #################################################################
        sort = np.argsort(similarities)[:, ::-1]  # descending
        mask = sort[:, k + 1:]  # indices to mask
        for i, row in enumerate(mask): similarities[i, row] = 0
        np.fill_diagonal(similarities, 0)  # remove self similarity
        return (similarities + similarities.T) / 2  # make the graph undirected

        return similarities


#################################################################
#################################################################


def build_laplacian(W, laplacian_normalization=""):
    #  laplacian_normalization:
    #      string selecting which version of the laplacian matrix to construct
    #      either 'unn'normalized, 'sym'metric normalization
    #      or 'rw' random-walk normalization

    #################################################################
    # build the laplacian                                           #
    # L: (n x n) dimensional matrix representing                    #
    #    the Laplacian of the graph                                 #
    #################################################################
    degree = W.sum(1)
    if not laplacian_normalization:
        return np.diag(degree) - W
    elif laplacian_normalization == "sym":
        aux = np.diag(1 / np.sqrt(degree))
        return np.eye(*W.shape) - aux.dot(W.dot(aux))
    elif laplacian_normalization == "rw":

        return np.eye(*W.shape) - np.diag(1 / degree).dot(W)

    else:
        raise ValueError


#################################################################
#################################################################


def plot_edges_and_points(X, Y, W, title=''):
    colors = ['go-', 'ro-', 'co-', 'ko-', 'yo-', 'mo-']
    n = len(X)
    G = nx.from_numpy_matrix(W)
    nx.draw_networkx_edges(G, X)
    for i in range(n):
        plt.plot(X[i, 0], X[i, 1], colors[int(Y[i])])
    plt.title(title)
    plt.axis('equal')


def plot_graph_matrix(X, Y, W):
    plt.figure()
    plt.clf()
    plt.subplot(1, 2, 1)
    plot_edges_and_points(X, Y, W)
    plt.subplot(1, 2, 2)
    plt.imshow(W, extent=[0, 1, 0, 1])
    plt.show()


def plot_clustering_result(X, Y, W, spectral_labels, kmeans_labels, normalized_switch=0):
    plt.figure()
    plt.clf()
    plt.subplot(1, 3, 1)
    plot_edges_and_points(X, Y, W, 'ground truth')
    plt.subplot(1, 3, 2)
    if normalized_switch:
        plot_edges_and_points(X, spectral_labels, W, 'unnormalized laplacian')
    else:
        plot_edges_and_points(X, spectral_labels, W, 'spectral clustering')
    plt.subplot(1, 3, 3)
    if normalized_switch:
        plot_edges_and_points(X, kmeans_labels, W, 'normalized laplacian')
    else:
        plot_edges_and_points(X, kmeans_labels, W, 'k-means')
    plt.show()


def plot_the_bend(X, Y, W, spectral_labels, eigenvalues_sorted):
    plt.figure()
    plt.clf()
    plt.subplot(1, 3, 1)
    plot_edges_and_points(X, Y, W, 'ground truth')

    plt.subplot(1, 3, 2)
    plot_edges_and_points(X, spectral_labels, W, 'spectral clustering')

    plt.subplot(1, 3, 3)
    plt.plot(np.arange(0, len(eigenvalues_sorted), 1), eigenvalues_sorted, 'v:')
    plt.show()


def plot_classification(X, Y, labels, var=1, eps=0, k=0):
    plt.figure()

    W = build_similarity_graph(X, var=var, eps=eps, k=k)

    plt.subplot(1, 2, 1)
    plot_edges_and_points(X, Y, W, 'ground truth')

    plt.subplot(1, 2, 2)
    plot_edges_and_points(X, labels, W, 'HFS')
    plt.show()


def label_noise(Y, alpha):
    ind = np.arange(len(Y))
    random.shuffle(ind)
    Y[ind[:alpha]] = 3 - Y[ind[:alpha]]
    return Y


def plot_classification_comparison(X, Y, hard_labels, soft_labels, var=1, eps=0, k=0):
    plt.figure()

    W = build_similarity_graph(X, var=var, eps=eps, k=k)

    plt.subplot(1, 3, 1)
    plot_edges_and_points(X, Y, W, 'ground truth')

    plt.subplot(1, 3, 2)
    plot_edges_and_points(X, hard_labels, W, 'Hard-HFS')

    plt.subplot(1, 3, 3)
    plot_edges_and_points(X, soft_labels, W, 'Soft-HFS')
    plt.show()


#regularisation=prenez +0.0001



def build_laplacian_regularized(X, laplacian_regularization ,laplacian_normalization="",var=1, eps=0, k=0):
    #      a skeleton function to construct a laplacian from data,
    #      needs to be completed
    #
    #  Input
    #  X:
    #      (n x m) matrix of m-dimensional samples
    #  laplacian_regularization:
    #      regularization to add to the laplacian

    # build the similarity graph W
    W = build_similarity_graph(X, var, eps, k)

    #################################################################
    # build the laplacian                                           #
    # L: (n x n) dimensional matrix representing                    #
    #    the Laplacian of the graph                                 #
    # Q: (n x n) dimensional matrix representing                    #
    #    the laplacian with regularization                          #
    #################################################################
    L=build_laplacian(W, laplacian_normalization=laplacian_normalization)
    Q=L+laplacian_regularization*np.identity(X.shape[0])
    #################################################################
    #################################################################
    return Q











def  mask_labels(Y, l):
    #      a skeleton function to select a subset of labels and mask the rest
    #
    #  Input
    #  Y:
    #      (n x 1) label vector, where entries Y_i take a value in [1..C] (num classes)
    #  l:
    #      number of unmasked (revealed) labels to include in the output
    #
    #  Output
    #  Y_masked:
    #      (n x 1) masked label vector, where entries Y_i take a value in [1..C]
    #           if the node is labeled, or 0 if the node is unlabeled (masked)

    num_samples = np.size(Y,0)

    #################################################################
    # randomly sample l nodes to remain labeled, mask the others    #
    #################################################################

    Y_masked = np.zeros(num_samples)


    Y_masked = np.array(Y).reshape(num_samples,1)
    Y_masked[random.sample(range(0, num_samples), (num_samples - l))] = np.zeros((num_samples - l)).reshape((num_samples - l),1)



    return Y_masked
    #################################################################
    #################################################################
















def hard_hfs(X, Y,laplacian_regularization ,laplacian_normalization="",var=1, eps=0, k=0):
#  a skeleton function to perform hard (constrained) HFS,
#  needs to be completed
#
#  Input
#  X:
#      (n x m) matrix of m-dimensional samples
#  Y:
#      (n x 1) vector with nodes labels [1, ... , num_classes] (0 is unlabeled)
#
#  Output
#  labels:
#      class assignments for each (n) nodes

    num_samples = np.size(X,0)
    Cl = np.unique(Y)
    num_classes = len(Cl)-1
    ####################################################################                         
    # l_idx = (l x num_classes) vector with indices of labeled nodes   #
    # u_idx = (u x num_classes) vector with indices of unlabeled nodes #
    ####################################################################

    l_idx = np.nonzero(Y)[0]
    u_idx = np.nonzero(Y == 0)[0]

    
    #################################################################
    # compute the hfs solution, remember that you can use           #
    #   build_laplacian_regularized and build_similarity_graph      #
    # f_l = (l x num_classes) hfs solution for labeled.             #
    # it is the one-hot encoding of Y for labeled nodes.            #
    # example:                                                      #
    # if Cl=[0,3,5] and Y=[0,0,0,3,0,0,0,5,5], then f_l is a 3x2    #
    # binary matrix where the first column codes the class '3'      #
    # and the second the class '5'.                                 #
    # In case of 2 classes, you can also use +-1 labels             #
    # f_u = (u x num_classes) hfs solution for unlabeled            #
    #################################################################
    L=build_laplacian_regularized(X, laplacian_regularization,laplacian_normalization,var=var, eps=eps, k=k)
    L_uu=L[:,u_idx][u_idx]
    L_ul=L[:,l_idx][u_idx]
    Y_l=Y[l_idx]
    n_values = np.max([int(Y_l[i]) for i in range(len(Y_l))])
    f_l=np.eye(n_values)[[int(Y_l[i]-1) for i in range(len(Y_l))]]

    f_u=np.linalg.inv(L_uu).dot(-L_ul.dot(f_l))

    #################################################################
    #################################################################

    #################################################################
    # compute the labels assignment from the hfs solution           #
    # label: (n x 1) class assignments [1,2,...,num_classes]        #
    #################################################################

    Y[u_idx]=np.argmax(f_u,axis=1)+1
    labels=Y

    #################################################################
    #################################################################
    return labels


    
def soft_hfs(X, Y, c_l, c_u, laplacian_regularization,laplacian_normalization="" ,var=1, eps=0, k=0):

    num_samples = np.size(X,0)
    Cl = np.unique(Y)
    num_classes = len(Cl)-1


    l_idx = np.nonzero(Y)[0]
    u_idx = np.nonzero(Y == 0)[0]
    Q = build_laplacian_regularized(X, laplacian_regularization,laplacian_normalization, var=var, eps=eps, k=k)
    #################################################################
    #################################################################
    #################################################################
    # compute the hfs solution, remember that you can use           #
    #   build_laplacian_regularized and build_similarity_graph      #
    # f = (n x num_classes) hfs solution                            #
    # C = (n x n) diagonal matrix with c_l for labeled samples      #
    #             and c_u otherwise                                 #
    #################################################################

    n_values = np.max([int(Y[i]) for i in range(len(Y))]) + 1
    y= np.eye(n_values)[[int(Y[i]) for i in range(len(Y))]]

    #for i in range(y.shape[0]):
        #for j in range(y.shape[1]):
            #if y[i][j] == 0:
                #y[i][j] = -1



    c=np.zeros(num_samples)
    c[np.nonzero(Y == 0)[0]]=[c_u]*len(u_idx)
    c[np.nonzero(Y)[0]]=[c_l]*len(l_idx)
    C=np.diag(c)
    #################################################################
    #################################################################

    #################################################################
    # compute the labels assignment from the hfs solution           #
    # label: (n x 1) class assignments [1, ... ,num_classes]        #
    #################################################################
    f = np.linalg.inv(np.linalg.inv(C).dot(Q) + np.eye(len(C))).dot(y[:,1:])
    labels = np.argmax(f, axis=1)+1



    #################################################################
    #################################################################
    return labels


def two_moons_hfs(mislabeled=0, soft=True,laplacian_normalization="",var=1,eps=0,k=0,large=0):
    # a skeleton function to perform HFS, needs to be completed
    # load the data
    if large==0:
        in_data = scipy.io.loadmat(path + '/ML_in_graphs/DM2/code_material_python/data/data_2moons_hfs')
    else :
        in_data = scipy.io.loadmat(path + '/ML_in_graphs/DM2/code_material_python/data/data_2moons_hfs_large')

    X = in_data['X']
    Y = in_data['Y']

    #################################################################
    # at home, try to use the larger dataset (question 1.2)         #
    #################################################################

    #################################################################
    #################################################################

    # automatically infer number of labels from samples
    num_samples = X.shape[0]

    num_classes = len(np.unique(Y))

    #################################################################
    # choose the experiment parameter                               #
    #################################################################

    l = 4  # number of labeled (unmasked) nodes provided to the hfs algorithm
    #################################################################
    #################################################################
    if mislabeled == 0:
        # mask labels
        Y_masked = mask_labels(Y, l)
        #################################################################
        # compute hfs solution using either soft_hfs.m or hard_hfs.m    #
        #################################################################


    else:
        Y_masked = mask_labels(Y, l)


        Y_masked[np.nonzero(Y_masked)[0]] = np.array([1, 2, 1, 1]).reshape(l, 1)

    if soft:
        labels = soft_hfs(X, Y_masked, 1, 0.000000001, 0.001, laplacian_normalization, var=var, eps=eps, k=k).reshape(num_samples,1)
    else:
        labels = hard_hfs(X, Y_masked, 0.001, laplacian_normalization, var=var, eps=eps, k=k).reshape(num_samples,1)
    #################################################################
    #################################################################
    plot_classification(X, Y, labels, var=var, eps=eps, k=k)
    accuracy = np.mean(labels == Y)

    return accuracy


def hard_vs_soft_hfs(laplacian_normalization="",var=1,k=0,eps=0):
    # a skeleton function to confront hard vs soft HFS, needs to be completed

    # load the data
    in_data =scipy.io.loadmat(path+'/ML_in_graphs/DM2/code_material_python/data/data_2moons_hfs')
    X = in_data['X']
    Y = in_data['Y']

    # automatically infer number of labels from samples
    num_samples = np.size(X,0)
    Cl = np.unique(Y)
    num_classes = len(Cl)-1
    
    # randomly sample 20 labels
    l = 20
    # mask labels
    Y_masked = mask_labels(Y, l)
    Y_masked[np.nonzero(Y_masked)[0]]=np.array([1,2,1,1,2,1,2,1,1,1,2,2,2,1,1,2,2,1,2,1]).reshape(l, 1)


    #Y_masked[np.nonzero(Y_masked)[0]] = label_noise(Y_masked[np.nonzero(Y_masked)[0]],l).reshape(l, 1)

    #Y_masked[np.nonzero(Y_masked)[0]] = label_noise(Y_masked[np.nonzero(Y_masked)[0]], l).reshape(l,1)

    #################################################################
    # choose the experiment parameter                               #
    #################################################################

   

    #################################################################
    #################################################################

    #################################################################
    # compute hfs solution using soft_hfs.m and hard_hfs.m          #
    # remember to use Y_masked (the vector with some labels hidden  #
    # as input and not Y (the vector with all labels revealed)      #
    #################################################################
    hard_labels = hard_hfs(X, Y_masked, 0.001, laplacian_normalization, var=var, eps=eps, k=k)

    soft_labels =soft_hfs(X, Y_masked, 1, 0.000000001, 0.001, laplacian_normalization, var=1, eps=eps, k=k)



    #################################################################
    #################################################################
    #Y_masked[np.nonzero(Y_masked == 0)[0]] = np.squeeze(Y)[np.nonzero(Y_masked == 0)[0]].reshape(0,1)
    #print('Ymask 2',Y_masked)

    plot_classification_comparison(X, Y,hard_labels, soft_labels,var=var, eps=eps, k=k)
    accuracy = [np.mean(hard_labels == Y), np.mean(soft_labels == Y)]
    return accuracy
